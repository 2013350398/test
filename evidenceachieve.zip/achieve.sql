use keshe;



-- ���е�
create table verify(
	achiev_no varchar(20) primary key,
	st_id varchar(20),
	submit_time datetime,
	me_id varchar(20),
	first_verify int default 0, 
	first_time datetime,
	ad_id varchar(20),
	last_verify int default 0,
	last_time datetime,
	FOREIGN KEY (st_id) REFERENCES student(st_id),
	FOREIGN KEY (me_id) REFERENCES mentor(me_id),
	FOREIGN KEY (ad_id) REFERENCES admin(ad_id),
	CHECK (last_verify=1 OR last_verify=-1 OR last_verify=0),
	CHECK (first_verify=1 OR first_verify=-1 OR first_verify=0),
);

create table thesis(
	achiev_no varchar(20) PRIMARY KEY,
	th_name varchar(50) NOT NULL,
	th_public varchar(50) NOT NULL,
	th_status varchar(12) NOT NULL,
	th_time Date NOT NULL,
	th_index varchar(20) NOT NULL,
	th_lib varchar(20) NOT NULL,
	th_evid Varchar(50) NOT NULL,
	FOREIGN KEY (achiev_no) REFERENCES verify(achiev_no),
	CHECK (th_status = '¼��δ����' OR th_status='�ѷ���'),
	CHECK (th_lib='ѧԺ���������Ŀ�' OR th_lib='ѧԺ�������Ŀ�' OR th_lib='����'),
);


 create table award(
	achiev_no varchar(20) PRIMARY KEY,
	aw_name varchar(50) NOT NULL,
	aw_level varchar(10) NOT NULL,
	aw_grade varchar(10) NOT NULL,
	aw_rank INT NOT NULL,
	aw_time Date NOT NULL,
	aw_evid varchar(50) NOT NULL,

	FOREIGN KEY (achiev_no) REFERENCES verify(achiev_no),
	CHECK (aw_level='���Ҽ�' OR aw_level='ʡ����' OR aw_level='�м�' OR aw_level='����'),
	CHECK (aw_grade='�صȽ�' OR aw_grade='һ�Ƚ�' OR aw_grade='���Ƚ�' OR aw_grade='���Ƚ�')
);

create table standard(
	achiev_no varchar(20) PRIMARY KEY,
	st_name varchar(50) NOT NULL,
	st_level varchar(20) NOT NULL,
	st_time Date,
	st_evid varchar(50),

	FOREIGN KEY (achiev_no) REFERENCES verify(achiev_no),
	CHECK (st_level='���ұ�׼' OR st_level='ʡ�����ط���׼' OR st_level='��ҵ��׼' OR st_level='�Ŷӱ�׼'),
);

create table report(
	achiev_no varchar(20) PRIMARY KEY,
	re_name varchar(50) NOT NULL,
	re_type varchar(10) NOT NULL,
	re_unit varchar(50) NOT NULL,
	re_time Date NOT NULL,
	re_contri INT NOT NULL,
	re_evid varchar(50) NOT NULL,

	FOREIGN KEY (achiev_no) REFERENCES verify(achiev_no),
	CHECK (re_type='�滮��' OR re_type='�����' OR re_type='������' OR re_type='����')
);

create table patent(
	achiev_no varchar(20) PRIMARY KEY,
	pa_name varchar(50) NOT NULL,
	pa_type varchar(20) NOT NULL,
	pa_no varchar(20) NOT NULL,
	pa_time Date NOT NULL,
	pa_status varchar(20) NOT NULL,
	pa_contri INT NOT NULL,
	pa_evid varchar(50) NOT NULL,

	FOREIGN KEY (achiev_no) REFERENCES verify(achiev_no),
	CHECK(pa_type='����ר��' OR pa_type='ʵ������ר��'),
);

create table development(
	achiev_no varchar(20) PRIMARY KEY,
	de_name varchar(50) NOT NULL,
	de_unit varchar(50) NOT NULL,
	de_time Date NOT NULL,
	de_contri INT NOT NULL,
	de_evid varchar(50) NOT NULL,

	FOREIGN KEY (achiev_no) REFERENCES verify(achiev_no),
);

create table textbook(
	achiev_no varchar(20) PRIMARY KEY,
	te_name varchar(50) NOT NULL,
	te_press varchar(50) NOT NULL,
	te_presstime Date NOT NULL,
	te_contri INT NOT NULL,
	te_evid varchar(50) NOT NULL,

	FOREIGN KEY (achiev_no) REFERENCES verify(achiev_no),
);

create table other(
	achiev_no varchar(20) PRIMARY KEY,
	ot_name varchar(50) NOT NULL,
	ot_time Date NOT NULL,
	ot_desc varchar(100) NOT NULL,
	ot_evid varchar(50) NOT NULL,

	FOREIGN KEY (achiev_no) REFERENCES verify(achiev_no),
);

-- ��ʦѧ����ϵ��
create table me_st(
	me_id varchar(20) NOT NULL,
	st_id varchar(20) NOT NULL,

	FOREIGN KEY (me_id) REFERENCES mentor(me_id),
	PRIMARY KEY (me_id, st_id),
	);